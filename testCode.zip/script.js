

let originalText = document.querySelector('#originalText').textContent
let inputText = document.querySelector('#inputText')

let outputEl = document.querySelector('.output')

const submit = document.querySelector('#submit')

submit.addEventListener('click', () => {
  let output = '';
  let userInput = inputText.value
  let oTextlength = originalText.length
  let uTextlength = userInput.length
  let i = 0
  let j = 0
  let isSmall = oTextlength > uTextlength ? true : false
while (i < oTextlength || j < uTextlength) {
  console.log(isSmall)
     if (userInput[j] === originalText[i]) {
      output += userInput[j]
      i++
      j++
    } 
    else {
     if (isSmall) {
      output += `<span class="green">${originalText[i]}</span>`;
      i++
     }
     if (!isSmall) {
       output += `<span class="highlight">${userInput[j]}</span>`;
       i++
       j++
     }
      
    }
}
  outputEl.innerHTML = output
})

/**

let originalText = document.querySelector('#originalText').textContent;
let inputText = document.querySelector('#inputText');
let outputEl = document.querySelector('.output');
const submit = document.querySelector('#submit');

submit.addEventListener('click', () => {
    let output = '';
    let userInput = inputText.value;
    let i = 0, j = 0;

    while (i < originalText.length || j < userInput.length) {
        if (i < originalText.length && j < userInput.length) {
            if (userInput[j] === originalText[i]) {
                // Characters match
                output += userInput[j];
                i++;
                j++;
            } else {
                // Mismatch: Prioritize showing original's missing character
                output += `<span class="green">${originalText[i]}</span>`;
                i++;
            }
        } else if (i < originalText.length) {
            // Remaining original characters are missing
            output += `<span class="green">${originalText[i]}</span>`;
            i++;
        } else {
            // Remaining user characters are extra
            output += `<span class="highlight">${userInput[j]}</span>`;
            j++;
        }
    }

    outputEl.innerHTML = output;
});
**/